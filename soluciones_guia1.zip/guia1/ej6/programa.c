#include <stdio.h>
#define DIMENSION 1024
int matriz[DIMENSION][DIMENSION];
int main(void) {
      printf("Hello World!\n");
      return 0;
}
